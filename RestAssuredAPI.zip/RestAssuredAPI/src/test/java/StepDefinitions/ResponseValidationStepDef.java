package StepDefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ResponseValidationStepDef {

    private  String body;



    @Given("^valid response api is available$")
    public void valid_response_api_is_available() {
        RestAssured.baseURI = "http://localhost:8080";
        Response response = RestAssured.when().get("/finance");
        response.then().assertThat().statusCode(200);
         body = response.getBody().asString();
    }

    @Then("match text {string} in response")
    public void match_text_in_response(String string) {
        Assert.assertTrue(body.contains(string));
    }

    @Then("match pattern {string} in response")
    public void match_pattern_in_response(String string) {
        Pattern validPattern = Pattern.compile(string);
        Matcher match = validPattern.matcher(body);
        Assert.assertTrue(match.find());
    }

    @Then("match {string} from response")
    public void match_in_response(String st) {
        Assert.assertTrue(body.contains(st));
    }
}
