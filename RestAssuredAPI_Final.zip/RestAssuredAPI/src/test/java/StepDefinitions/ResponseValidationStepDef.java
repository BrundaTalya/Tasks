package StepDefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ResponseValidationStepDef {

    private  String body;



    @Given("^valid response api is available$")
    public void valid_response_api_is_available() {
        RestAssured.baseURI = "http://localhost:8080";
        Response response = RestAssured.when().get("/finance");
        response.then().assertThat().statusCode(200);
         body = response.getBody().asString();
    }

    @Then("match text {string} in response")
    public void match_text_in_response(String string) {
        Assert.assertTrue(body.contains(string));
    }

    @Then("match pattern {string} in response")
    public void match_pattern_in_response(String string) {
        System.out.println(string);
        Pattern validPattern = Pattern.compile(string);
        Matcher match = validPattern.matcher(body);
        Assert.assertTrue(match.find());

    }


    @Then("match {string} from response")
    public void match_in_response(String st) {
        Assert.assertTrue(body.contains(st));
    }

    @Then("match {string}")
    public void match_with(String date) {
        // Write code here that turns the phrase above into concrete actions
  //      Pattern validPattern = Pattern.compile(".?([0-9]{2})(/|-)([0-9]{2})(/|-)([0-9]{4}).?");
        Pattern validPattern = Pattern.compile(".?(\\d{2})(/|-)(\\d{2})(/|-)(\\d{4}).?");
        Matcher match = validPattern.matcher(date);
        Assert.assertTrue(match.find());
    }



}
