import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;


import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.RandomStringGenerator;
import org.apache.commons.text.CharacterPredicates;

// Latest Version

public class TestData {
    public static void main(String[] args) throws IOException {


        // Create file
        String fileName = "Test File Finance";
        if (args.length > 0) {
            fileName = args[0];
        }
        File file = new File(fileName + ".txt");

        Path outputPath = Paths.get(String.valueOf(file));

        List<String> content = new ArrayList<String>();

        // Print header
        content.add(getHeader());

        //Print body
        content.add(printBody());
        Files.write(outputPath, content);
    }


    public static String printBody() {
        int lineCounter = 1;                    // Track line counter
        int totalLines = 600;                   // Total lines
        int pageCounter = 1;                    // Track page counter
        int counter = 0;                        // Total line counter
        boolean isCurrencyPrinted = false;      // Flag to print money format in EACH page
        boolean isOncePrinted = false;          // Flag to print string ONCE
        boolean isTwicePrinted = false;         // Flag to print string TWICE
        boolean isReleasedOnce = false;         // Flag to release lock ONCE

        String line ="";
        String content="";
        String[] span = {"5", "7"};             // word separator positions - 5,7
        String[] chars = {", ", ". "};          // word separators

        // Build body of totalLines (600) length
        while (counter <= totalLines){
            // Every set of 50 lines
            if (lineCounter <= 50) {
                line = "";
                int wordCount = 0;

                // Build line
                while (line.length() < 80) {
                    String word = getRandomString();
                    wordCount++;

                    // Add word separators at random places of words
                    if (wordCount > Integer.parseInt(getRandom(span))) {
                        line += word + getRandom(chars);
                        wordCount = 0;
                    } else {
                        line += (word + " ");
                    }

                    // Print the required strings after 20th(random) line
                    if (lineCounter > 20) {
                        // Print in every page
                        if (!isCurrencyPrinted) {
                            line += getMoneyChar();
                            line += " testing ";
                            isCurrencyPrinted = true;
                        }

                        // Print twice in file
                        if((totalLines % (totalLines/2) == 0) && !isTwicePrinted) {
                            line += " finance ";
                            // Lock to not print "finance" again
                            isTwicePrinted = true;
                        }

                        // Print once in file
                        if (counter < (totalLines / 2) && !isOncePrinted) {
                            line += " Finance ";
                            isOncePrinted = true;
                        }
                    }

                }
                content += (line + "\n");
                lineCounter++;

                // At the end of the body, print <EOF> with blank lines
                if (counter == totalLines)
                {
                    // Add blank lines till 49
                    while (lineCounter <50)
                    {
                        content+= ("\n");
                        lineCounter++;
                    }
                    content+= ("<EOF>" + "\n");
                    content+= (getFooter().replace("%N%", Integer.toString(pageCounter)));
                }

                // Print "finance" second time in second set of 300
                else if (counter > (totalLines / 2))
                {
                    // Release lock only once
                    if(!isReleasedOnce)
                    {
                        // Release lock to print "finance"
                        isTwicePrinted = false;
                        isReleasedOnce = true;
                    }
                }
                counter++;
            }
            // Every 50 lines print footer and header, reset essential counters/flags
            else if(lineCounter==51)
            {
                // Print footer
                content+= (getFooter().replace("%N%", Integer.toString(pageCounter)) + "\n");
                pageCounter += 1;
                content+=(getHeader() + "\n");
                lineCounter=0;
                isCurrencyPrinted = false;
                counter++;
            }
        }
        return content;
    }

    /**
     * Returns header
     * @return
     */
    public static String getHeader()
    {
        // Add first line of the header
        String header1 = StringUtils.repeat("=", 80);

        // Form second line of the header
        String header2 = StringUtils.leftPad("Sample Company", 80);

        return header1 + "\n" + header2;
    }

    /**
     * Returns random string to build body
     * @return
     */
    public static String getRandomString()
    {

        final char[][] pairs = {{'A', 'Z'}, {'a', 'z'}};
        String randomLetters = "";
        RandomStringGenerator generator = new RandomStringGenerator.Builder()
                .withinRange(pairs)
                .filteredBy(CharacterPredicates.LETTERS)
                .build();
        randomLetters = generator.generate(1,10);

        return randomLetters;
    }

    /**
     * Returns random element from the given array
     * @param array Array Data
     * @return Random element
     */
    public static String getRandom(String[] array) {
        int rnd = new Random().nextInt(array.length);
        return array[rnd];
    }

    /**
     * Returns Random Money format string
     */
    public static String getMoneyChar() {
        long generatedLong = new Random().nextLong();
        NumberFormat currency = NumberFormat.getCurrencyInstance(Locale.US);
        String myCurrency = currency.format(generatedLong);
        return myCurrency;
    }

    /**
     * Returns footer
     */
    public static String getFooter()
    {
        // Add first line of the footer
        String footer1 = StringUtils.repeat("-", 65);

        // Placeholder for page number
        String footer2 = StringUtils.center("%N%", 65);

        // Add padding - empty spaces to position the page number at center
        String footer3 = StringUtils.rightPad("S a m p l e  C o m p a n y", 65);

        // Concatenate 3 footer lines
        return footer1 + "\n" + footer2 + "\n" + footer3;
    }
}
